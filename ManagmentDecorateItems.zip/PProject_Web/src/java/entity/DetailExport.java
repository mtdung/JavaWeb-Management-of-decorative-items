/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Funny
 */
public class DetailExport {
    private int stt;
    private int id;
    private int idbill;
    private float amount;
    private int unitprice;
    private int price;

    public DetailExport() {
    }

    public DetailExport(int stt, int id, int idbill, float amount, int unitprice, int price) {
        this.stt = stt;
        this.id = id;
        this.idbill = idbill;
        this.amount = amount;
        this.unitprice = unitprice;
        this.price = price;
    }

    public int getStt() {
        return stt;
    }

    public void setStt(int stt) {
        this.stt = stt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdbill() {
        return idbill;
    }

    public void setIdbill(int idbill) {
        this.idbill = idbill;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public int getUnitprice() {
        return unitprice;
    }

    public void setUnitprice(int unitprice) {
        this.unitprice = unitprice;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Detail_Export{" + "stt=" + stt + ", id=" + id + ", idbill=" + idbill + ", amount=" + amount + ", unitprice=" + unitprice + ", price=" + price + '}';
    }
}

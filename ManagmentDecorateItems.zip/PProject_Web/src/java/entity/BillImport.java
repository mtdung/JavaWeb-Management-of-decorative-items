/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.sql.Date;

/**
 *
 * @author Funny
 */
public class BillImport {
    private int id;
    private int idprovider;
    private Date date;
    private int total;
    private int cost;

    public BillImport() {
    }

    public BillImport(int id, int idprovider, Date date, int total, int cost) {
        this.id = id;
        this.idprovider = idprovider;
        this.date = date;
        this.total = total;
        this.cost = cost;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdprovider() {
        return idprovider;
    }

    public void setIdprovider(int idprovider) {
        this.idprovider = idprovider;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "BillImport{" + "id=" + id + ", idprovider=" + idprovider + ", date=" + date + ", total=" + total + ", cost=" + cost + '}';
    }

    
}

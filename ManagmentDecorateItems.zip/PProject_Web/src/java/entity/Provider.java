/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Funny
 */
public class Provider {
    private int id;
    private String name;
    private String address;
    private String phone;
    private int total;
    private int cost;

    public Provider() {
    }

    public Provider(int id, String name, String address, String phone, int total, int cost) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.total = total;
        this.cost = cost;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "Provider{" + "id=" + id + ", name=" + name + ", address=" + address + ", phone=" + phone + ", total=" + total + ", cost=" + cost + '}';
    }
}

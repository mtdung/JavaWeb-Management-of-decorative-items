/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DBContext.DBContext;
import entity.Customer;
import entity.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Funny
 */
public class CustomerDAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<Customer> getAllCustomer() {
        List<Customer> list = new ArrayList<>();
        String querry = "select * from Customer";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Customer(rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getInt(5), rs.getInt(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Customer getCustomerByID(String id) {
        String querry = "select * from Customer\n"
                + "where id_customer = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                Customer c = new Customer(rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getInt(5), rs.getInt(6));
                return c;
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void updateCustomer(String id, String name, String address, String phone, String cost) {
        String querry = "UPDATE [dbo].[Customer]\n"
                + "   SET [name_customer] = ?\n"
                + "      ,[adress] = ?\n"
                + "      ,[phone] = ?\n"
                + "      ,[Totalcost] = ?\n"
                + " WHERE id_customer = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3, phone);
            ps.setString(4, cost);
            ps.setString(5, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void insertCustomer(String id, String name, String address, String phone,
            String total, String cost) {
        String querry = "INSERT INTO [dbo].[Customer]\n"
                + "           ([id_customer]\n"
                + "           ,[name_customer]\n"
                + "           ,[adress]\n"
                + "           ,[phone]\n"
                + "           ,[Total]\n"
                + "           ,[Totalcost])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, address);
            ps.setString(4, phone);
            ps.setString(5, total);
            ps.setString(6, cost);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void deleteCustomer(String id) {
        String querry = "DELETE FROM [dbo].[Customer]\n"
                + "      WHERE id_customer = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        CustomerDAO dao = new CustomerDAO();
        Customer c = dao.getCustomerByID("1");
        System.out.println(c);
    }
}

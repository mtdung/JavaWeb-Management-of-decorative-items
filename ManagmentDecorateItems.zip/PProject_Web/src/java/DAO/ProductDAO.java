/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DBContext.DBContext;
import entity.Account;
import entity.CategoryProduct;
import entity.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale.Category;

/**
 *
 * @author Funny
 */
public class ProductDAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<Product> getAllProduct() {
        List<Product> list = new ArrayList<>();
        String querry = "select * from Product";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(1),
                        rs.getInt(2), rs.getString(3),
                        rs.getFloat(4), rs.getInt(5)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Product getProductbyID(String id) {
        String querry = "select * from Product\n"
                + "where id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Product(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getInt(4),
                        rs.getInt(5));
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<CategoryProduct> getAllCategory() {
        List<CategoryProduct> list = new ArrayList<>();
        String querry = "select * from Category_Product";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new CategoryProduct(rs.getInt(1), rs.getString(2)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Product> searchByCate(String cateid) {
        List<Product> list = new ArrayList<>();
        String querry = "select * from Product\n"
                + "where id_cate = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, cateid);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getInt(4),
                        rs.getInt(5)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public void insertProduct(String id, String cid, String name, String amount, String price) {
        String querry = "INSERT INTO [dbo].[Product]\n"
                + "           ([id]\n"
                + "           ,[id_cate]\n"
                + "           ,[name]\n"
                + "           ,[amountwarehouse]\n"
                + "           ,[price])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            ps.setString(2, cid);
            ps.setString(3, name);
            ps.setString(4, amount);
            ps.setString(5, price);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void updateProduct(String id, String cateid, String name, String amount, String price) {
        String querry = "UPDATE [dbo].[Product]\n"
                + "   SET \n"
                + "      [id_cate] = ?\n"
                + "      ,[name] = ?\n"
                + "      ,[amountwarehouse] = ?\n"
                + "      ,[price] = ?\n"
                + " WHERE id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, cateid);
            ps.setString(2, name);
            ps.setString(3, amount);
            ps.setString(4, price);
            ps.setString(5, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void deleteProduct(String id) {
        String query = "delete from Product \n"
                + "where id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    
}

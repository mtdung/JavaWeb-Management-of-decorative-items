/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DBContext.DBContext;
import entity.BillImport;
import entity.DetailImport;
import entity.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Funny
 */
public class BillImportDAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<BillImport> getAllBillImport() {
        List<BillImport> list = new ArrayList<>();
        String querry = "select * from BillImport";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new BillImport(rs.getInt(1), rs.getInt(2),
                        rs.getDate(3), rs.getInt(5), rs.getInt(4)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public void insertBillImport(String bid, String idprovider, String cost, String total) {
        String querry = "INSERT INTO [dbo].[BillImport]\n"
                + "           ([id_bill]\n"
                + "           ,[id_provider]\n"
                + "           ,[date_import]\n"
                + "           ,[cost]\n"
                + "           ,[Total_Price])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,GETDATE()\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, bid);
            ps.setString(2, idprovider);
            ps.setString(3, cost);
            ps.setString(4, total);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public List<DetailImport> getDetailBill(String bid) {
        List<DetailImport> list = new ArrayList();
        String querry = "select row_number() over(order by STT asc) as STT, id_product , id_bill, amountproduct , unitprice , price from Detail_Import\n"
                + "where id_bill = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, bid);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new DetailImport(rs.getInt(1), rs.getInt(2), rs.getInt(3),
                        rs.getInt(4), rs.getInt(5), rs.getInt(6)));
            }
        } catch (Exception ex) {
            Logger.getLogger(BillImportDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    public void insertDetailImport(String pid, String bid, String amount, String unitprice, int price) {
        String querry = "INSERT INTO [dbo].[Detail_Import]\n"
                + "           ([id_product]\n"
                + "           ,[id_bill]\n"
                + "           ,[amountproduct]\n"
                + "           ,[unitprice]\n"
                + "           ,[price])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, pid);
            ps.setString(2, bid);
            ps.setString(3, amount);
            ps.setString(4, unitprice);
            ps.setInt(5, price);
            ps.executeUpdate();
        } catch (Exception e) {

        }
    }

    public DetailImport getDetailImportBySTT(String STT) {
        String querry = "select row_number() over(order by STT asc) as STT, id_product , id_bill, amountproduct , unitprice , price from Detail_Import\n"
                + "where STT = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, STT);
            rs = ps.executeQuery();
            while (rs.next()) {
                DetailImport d = new DetailImport(rs.getInt(1), rs.getInt(2), rs.getInt(3),
                        rs.getInt(4), rs.getInt(5), rs.getInt(6));
                return d;
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void updateDetailImport(String stt, String pid, String bid,
            String amount, String unitprice, int price) {
        String querry = "UPDATE [dbo].[Detail_Import]\n"
                + "   SET [id_product] = ?\n"
                + "      ,[id_bill] = ?\n"
                + "      ,[amountproduct] = ?\n"
                + "      ,[unitprice] = ?\n"
                + "      ,[price] = ?\n"
                + " WHERE STT = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, pid);
            ps.setString(2, bid);
            ps.setString(3, amount);
            ps.setString(4, unitprice);
            ps.setInt(5, price);
            ps.setString(6, stt);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        BillImportDAO dao = new BillImportDAO();
        dao.insertBillImport("1", "1", "1000000", "0");
    }
}

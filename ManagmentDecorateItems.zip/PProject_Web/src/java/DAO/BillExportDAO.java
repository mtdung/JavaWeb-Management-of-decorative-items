/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DBContext.DBContext;
import entity.BillExport;
import entity.DetailExport;
import entity.DetailImport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Funny
 */
public class BillExportDAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<BillExport> getAllBillExport() {
        List<BillExport> list = new ArrayList<>();
        String querry = "select * from BillExport";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new BillExport(rs.getInt(1), rs.getInt(2),
                        rs.getDate(3), rs.getInt(5), rs.getInt(4)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public void insertBillExport(String id, String cusid, String cost, String total) {
        String querry = "INSERT INTO [dbo].[BillExport]\n"
                + "           ([id_bill]\n"
                + "           ,[id_customer]\n"
                + "           ,[date]\n"
                + "           ,[cost]\n"
                + "           ,[Total_price])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,GETDATE()\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            ps.setString(2, cusid);
            ps.setString(3, cost);
            ps.setString(4, total);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public List<DetailExport> getDetailExport(String bid) {
        List<DetailExport> list = new ArrayList<>();
        String querry = "select * from Detail_Export\n"
                + "where id_bill = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, bid);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new DetailExport(rs.getInt(1), rs.getInt(2), rs.getInt(3),
                        rs.getFloat(4), rs.getInt(5), rs.getInt(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public void insertDeatilExport(String pid, String bid, String amount, String unitprice, int price) {
        String querry = "INSERT INTO [dbo].[Detail_Export]\n"
                + "           ([id_product]\n"
                + "           ,[id_bill]\n"
                + "           ,[amountproduct]\n"
                + "           ,[unitprice]\n"
                + "           ,[price])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, pid);
            ps.setString(2, bid);
            ps.setString(3, amount);
            ps.setString(4, unitprice);
            ps.setInt(5, price);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public DetailExport getDetailExportBy(String stt) {
        String querry = "select * from Detail_Export\n"
                + "where STT = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, stt);
            rs = ps.executeQuery();
            while (rs.next()) {
                DetailExport d = new DetailExport(rs.getInt(1), rs.getInt(2), rs.getInt(3),
                        rs.getFloat(3), rs.getInt(5), rs.getInt(6));
                return d;
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void updateDetailExport(String stt, String pid, String bid,
            String amount, String unitprice, int price) {
        String querry = "UPDATE [dbo].[Detail_Export]\n"
                + "   SET [id_product] = ?\n"
                + "      ,[id_bill] = ?\n"
                + "      ,[amountproduct] = ?\n"
                + "      ,[unitprice] = ?\n"
                + "      ,[price] = ?\n"
                + " WHERE STT = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, pid);
            ps.setString(2, bid);
            ps.setString(3, amount);
            ps.setString(4, unitprice);
            ps.setInt(5, price);
            ps.setString(6, stt);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        BillExportDAO dao = new BillExportDAO();
        List<BillExport> list = dao.getAllBillExport();
        for (BillExport o : list) {
            System.out.println(o);
        }
    }
}

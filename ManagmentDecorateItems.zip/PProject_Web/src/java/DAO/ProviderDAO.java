/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DBContext.DBContext;
import entity.BillImport;
import entity.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Funny
 */
public class ProviderDAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<Provider> getAllProvider() {
        List<Provider> list = new ArrayList<>();
        String querry = "select * from [Provider]";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Provider(rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getInt(5), rs.getInt(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Provider getProviderByID(String id) {
        String querry = "select * from Provider\n"
                + "where id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                Provider p = new Provider(rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getInt(5), rs.getInt(6));
                return p;
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void updateProvider(String id, String name, String address,
            String phone, String cost) {
        String querry = "UPDATE [dbo].[Provider]\n"
                + "   SET "
                + "      [name_provider] = ?\n"
                + "      ,[address] = ?\n"
                + "      ,[phone] = ?\n"
                + "      ,[Totalcost] = ?\n"
                + " WHERE id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3, phone);
            ps.setString(4, cost);
            ps.setString(5, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void insertProvider(String id, String name, String address, String phone,
            String total, String cost) {
        String querry = "INSERT INTO [dbo].[Provider]\n"
                + "           ([id]\n"
                + "           ,[name_provider]\n"
                + "           ,[address]\n"
                + "           ,[phone]\n"
                + "           ,[Total]\n"
                + "           ,[Totalcost])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, address);
            ps.setString(4, phone);
            ps.setString(5, total);
            ps.setString(6, cost);
            ps.executeUpdate();
        } catch (Exception ex) {
            Logger.getLogger(ProviderDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void deleteProvider(String id) {
        String querry = "DELETE FROM [dbo].[Provider]\n"
                + "      WHERE id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        ProviderDAO dao = new ProviderDAO();
        dao.updateProvider("3", "Nguyen Van A", "HA NOI", "0563887898", "1000000");
    }
}
